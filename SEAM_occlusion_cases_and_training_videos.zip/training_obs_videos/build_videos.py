from pathlib import Path
import csv,json,hashlib,subprocess,concurrent.futures
from PIL import Image,ImageDraw,ImageFont
ROOT=Path("/home/CNS2026330003/Downloads/raw_observations_20261026")
OUT=ROOT/"audit_outputs/training_obs_videos"
OUT.mkdir(exist_ok=True)
EPISODES=[
"images/controlled_ablation_20261026/robot_v2/runs/episode_0001_attempt_04",
"images/full_observation_20261026_163345_062521/episode_0001",
"images/full_observation_20261026_171618_192631/episode_0001",
"images/sleeve_hem_batch_20261026_192253_802692104/episode_0001",
"images/sleeve_hem_batch_20261026_194909_153537996/episode_0002"]
rows=list(csv.DictReader((ROOT/"observations.csv").open(encoding="utf-8-sig")))
font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",18)
small=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",16)
def build(item):
    idx,ep=item
    rs=sorted((r for r in rows if r["image"].startswith(ep+"/")),key=lambda r:(float(r["timestamp"]),r["image"]))
    assert rs and all(r["timestamp"] for r in rs)
    name=f"train_obs_{idx:02d}"; target=OUT/(name+".mp4")
    cmd=["ffmpeg","-hide_banner","-loglevel","error","-y","-f","rawvideo","-pixel_format","rgb24","-video_size","1280x800","-framerate","1","-i","pipe:0","-an","-c:v","libx264","-preset","veryfast","-crf","18","-threads","2","-r","24","-pix_fmt","yuv420p","-movflags","+faststart",str(target)]
    manifest=[]
    with (OUT/(name+"_encoding.log")).open("w") as err:
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=err)
        try:
            for i,r in enumerate(rs):
                source=ROOT/r["image"]
                with Image.open(source) as im:
                    assert im.size==(1280,720)
                    frame=Image.new("RGB",(1280,800),(18,22,30))
                    frame.paste(im.convert("RGB"),(0,80))
                draw=ImageDraw.Draw(frame)
                stage=r["image"][len(ep)+1:]
                draw.text((16,7),f"TRAIN OBS {idx:02d} | OBSERVATION REPLAY | {i+1:03d}/{len(rs):03d} | 1 s / obs (not real time)",font=font,fill="white")
                draw.text((16,32),ep.removeprefix("images/"),font=small,fill=(180,200,215))
                draw.text((16,55),f"{r['captured_time']} | {stage}",font=small,fill=(140,225,185))
                proc.stdin.write(frame.tobytes())
                manifest.append(dict(video=name+".mp4",observation_index=i+1,start_s=i,end_s=i+1,source_image=r["image"],captured_time=r["captured_time"],timestamp=r["timestamp"],stage=stage,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
            proc.stdin.close()
            if proc.wait()!=0: raise RuntimeError("ffmpeg failed: "+name)
        except BaseException:
            proc.kill();proc.wait();raise
    with (OUT/(name+"_frames.csv")).open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(manifest[0]));w.writeheader();w.writerows(manifest)
    probe=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_entries","stream=codec_name,width,height,nb_frames,avg_frame_rate:format=duration,size","-of","json",str(target)]))
    stream=probe["streams"][0]
    assert stream["codec_name"]=="h264" and stream["width"]==1280 and stream["height"]==800
    assert int(stream["nb_frames"])==24*len(rs)
    assert abs(float(probe["format"]["duration"])-len(rs))<0.1
    subprocess.run(["ffmpeg","-v","error","-i",str(target),"-f","null","-"],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    result=dict(id=name,video=target.name,episode=ep,observations=len(rs),duration_seconds=len(rs),capture_span_seconds=float(rs[-1]["timestamp"])-float(rs[0]["timestamp"]),first_image=rs[0]["image"],last_image=rs[-1]["image"],round_count=len({r["image"][len(ep)+1:].split("/")[0] for r in rs if r["image"][len(ep)+1:].startswith("round_")}),original_train_split="unknown",intended_use="training material per user request",task_terminal_success="unknown",coverage="all observations saved for this episode in the supplied export",validation=probe,decoded_without_errors=True)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(build,enumerate(EPISODES,1)))
(OUT/"manifest.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
summary=Image.new("RGB",(1280,5*385),"white");draw=ImageDraw.Draw(summary)
for i,r in enumerate(results):
    for j,key in enumerate(["first_image","last_image"]):
        with Image.open(ROOT/r[key]) as im:
            im=im.resize((640,360));summary.paste(im,(640*j,385*i))
    draw.text((10,385*i+362),f"{r['id']} | FIRST -> LAST | {r['observations']} obs | {r['duration_seconds']} s | {r['round_count']} rounds",font=small,fill="black")
summary.save(OUT/"first_last_preview.jpg",quality=90)
lines=["五条训练用途观测序列回放","",
"按用户要求制作 5 条 MP4；训练用途为本次指定，原始数据未包含 train/test split，未据此声称已有训练集归属。",
"每条均选取不同 run 的一个 episode，从初始化 before 到最后保存的 round after；所有普通 round 均有前后图。保留该 episode 在 CSV 中的全部 obs，包括 pre_execution、depth_pair/closed、重规划和恢复观测；不去重、不跨 episode 拼接。",
"按原始 timestamp 数值升序；每张展示 1 秒，输出 24 fps、H.264、1280×800、无音频。原始 1280×720 图像完整保留在画面下方，上方新增 80 px 状态栏。",
"这是离散观测图回放，不含真实连续运动；不按真实采集间隔播放。完整仅指当前导出包中已保存的该 episode 观测全覆盖；无执行日志与 DONE/成功标签，不能证明任务成功终止。",
"",
"视频 | obs 数 | 时长 | round 数 | episode"]
lines += [f"{r['video']} | {r['observations']} | {r['duration_seconds']} s | {r['round_count']} | {r['episode']}" for r in results]
lines += ["","验证：五条视频均经 ffprobe 检查分辨率、编码、时长、帧数，并通过全片解码；每个源图路径、时间戳和 SHA-256 见对应 *_frames.csv。","原始图片和 CSV 未改动。未生成新模型推理、动作或 failure 标签。","注意：这些源数据可能与先前遮挡案例存在 episode 重叠；后续如划分评测集，需按 episode 排除重叠。"]
(OUT/"README.txt").write_text("\n".join(lines)+"\n")
print("COMPLETE",len(results),sum(r["observations"] for r in results),flush=True)
