五条训练用途观测序列回放

按用户要求制作 5 条 MP4；训练用途为本次指定，原始数据未包含 train/test split，未据此声称已有训练集归属。
每条均选取不同 run 的一个 episode，从初始化 before 到最后保存的 round after；所有普通 round 均有前后图。保留该 episode 在 CSV 中的全部 obs，包括 pre_execution、depth_pair/closed、重规划和恢复观测；不去重、不跨 episode 拼接。
按原始 timestamp 数值升序；每张展示 1 秒，输出 24 fps、H.264、1280×800、无音频。原始 1280×720 图像完整保留在画面下方，上方新增 80 px 状态栏。
这是离散观测图回放，不含真实连续运动；不按真实采集间隔播放。完整仅指当前导出包中已保存的该 episode 观测全覆盖；无执行日志与 DONE/成功标签，不能证明任务成功终止。

视频 | obs 数 | 时长 | round 数 | episode
train_obs_01.mp4 | 53 | 53 s | 13 | images/controlled_ablation_20261026/robot_v2/runs/episode_0001_attempt_04
train_obs_02.mp4 | 59 | 59 s | 13 | images/full_observation_20261026_163345_062521/episode_0001
train_obs_03.mp4 | 53 | 53 s | 13 | images/full_observation_20261026_171618_192631/episode_0001
train_obs_04.mp4 | 25 | 25 s | 6 | images/sleeve_hem_batch_20261026_192253_802692104/episode_0001
train_obs_05.mp4 | 49 | 49 s | 12 | images/sleeve_hem_batch_20261026_194909_153537996/episode_0002

验证：五条视频均经 ffprobe 检查分辨率、编码、时长、帧数，并通过全片解码；每个源图路径、时间戳和 SHA-256 见对应 *_frames.csv。
原始图片和 CSV 未改动。未生成新模型推理、动作或 failure 标签。
注意：这些源数据可能与先前遮挡案例存在 episode 重叠；后续如划分评测集，需按 episode 排除重叠。
